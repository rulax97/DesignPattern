class Impresora extends Base
{
	public void ImprimeImpresora(String nombre_archivo)
	{
		String nombre_archivo2;
		nombre_archivo2 = "Impresora";
		nombre_archivo=nombre_archivo2;
	}
	public int numeroTrabajosEsperaImpresora()
	{
		return 5;
	}
	public void LimpiaPrintingQueueImpresora()
	{
		System.out.println("Impresora limpia.");
	}
}
