class Base
{
	public String Nnombre;
 	public int Nnumero;
	public float Ntotal;
	public int getNImpresora()
	{
		return Nnumero=1;
	}
	public String getImpresora()
	{
		return Nnombre="Objeto Impresora";
	}
	public int getNPlotter()
	{
		return Nnumero=2;
	}
	public String getPlotter()
	{
		return Nnombre="Objeto Plotter";
	}
	public float getNCaja()
	{
		return Ntotal=3;
	}
	public void getCaja()
	{
		System.out.println("Objeto Caja");
	}
}
