class Fabrica
{
	public Base getBase(String palabra)
	{
		return new Impresora();
	}
	public Base getBasePlotter(String palabra)
	{
		return new Plotter();
	}
	public Base getBaseCaja(String palabra)
	{
		return new Caja();
	}
}
