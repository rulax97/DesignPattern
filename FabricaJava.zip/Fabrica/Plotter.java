class Plotter extends Base
{
		public void ImprimePlotter(String nombre_archivo)
		{
			String nombre_archivo2;
			nombre_archivo2 = "Plotter";
			nombre_archivo=nombre_archivo2;
		}
		public int numeroTrabajosEsperaPlotter()
		{
			return 5;
		}
		public void LimpiaPrintingQueuePlotter()
		{
			System.out.println("Plotter limpio.");
		}
}
