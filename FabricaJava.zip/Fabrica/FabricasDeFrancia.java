import java.util.Scanner;
class FabricasDeFrancia
{
   public static void main(String args[])
   {
     Fabrica nFabrica = new Fabrica();
     String w;
     String s="Ejemplo";
     int n,n2;
     float y;
     Base Oject = nFabrica.getBase(s);
     n = Oject.getNImpresora();
     w = Oject.getImpresora();
     System.out.println(w);
     System.out.println(n);
     Base Oject2 = nFabrica.getBasePlotter(s);
     n = Oject2.getNPlotter();
     w = Oject2.getPlotter();
     System.out.println(w);
     System.out.println(n);
     Base Oject3 = nFabrica.getBaseCaja(s);
     y = Oject3.getNCaja();
     Oject3.getCaja();
     System.out.println(y);
   }
 }
