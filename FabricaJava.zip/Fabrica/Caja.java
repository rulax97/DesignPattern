class Caja extends Base
{
	public void AbreCajaRegistradora()
	{
    System.out.println("Caja limpia.");
	}
	public float totalAPagar()
	{
		return 15;
	}
	public float EstableceMontoAPagar(float cantidad)
	{
    float x;
    x=1;
    cantidad=x;
		return x;
	}
}
